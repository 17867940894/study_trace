package Demo1.dao;

import Demo1.javabean.User;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class UserDao {

    QueryRunner qr = new QueryRunner(new ComboPooledDataSource());

    public boolean findUsername(User u) throws SQLException {
        String sql = "select user_id id,user_name username,user_password password from user";
        List<User> list = qr.query(sql , new BeanListHandler<User>(User.class));
        for (User user : list) {
            if (user.getUsername().equals(u.getUsername())){
                return true;
            }
        }
        return false;
    }

    public void saveUser(User u) throws SQLException {
        String sql = "insert into user value(null , ? , ? )";
        qr.update(sql , u.getUsername() , u.getPassword());
    }

    public boolean findUser(User u) throws SQLException {
        String sql = "select user_id id,user_name username,user_password password from user";
        List<User> list = qr.query(sql , new BeanListHandler<User>(User.class));
        for (User user : list) {
            if (user.getUsername().equals(u.getUsername()) && user.getPassword().equals(u.getPassword())){
                return true;
            }
        }
        return false;
    }
}
